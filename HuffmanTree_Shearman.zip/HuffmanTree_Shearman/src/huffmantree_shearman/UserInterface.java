/*
* Name: Walker Shearman
* Class: CSCI 303 - A - Advanced Data Structures and Algorithms 1, Fall 2021
* Date: 11/4/21
*/

package huffmantree_shearman;

import java.util.InputMismatchException;
import java.util.Scanner;

//@author Dr Jenny
public class UserInterface 
{
    public static void printCode(HuffmanNode root, String s)
    {
        if (root.left == null && root.right ==null)
        {
            //c is the character in the node
            System.out.println(root.c + ":" + s);
            return;
        }
        printCode(root.left, s + "0");
        printCode(root.right, s + "1");
    }
    
    public static void ObtainCharacters(PhraseAndFrequencies PF)
    {
        String line;
        Scanner userInput = new Scanner (System.in );
        while(true)
        {
            try
            {
                System.out.println("Please enter a phrase.");
                line = userInput.nextLine();
                
                if(!(line instanceof String) || line == null || line == "")
                {
                    System.out.println("Error: Incorrect input provided.");
                }
                else
                {
                    //convert to a character array.
                    for (char ch: line.toCharArray())
                    {
                        if (PF.checkCharacter(ch) == -1)
                        {
                            //does not exist, so add it.
                            PF.AddCharacter(ch);
                        }
                        else
                        {
                            //exissts, so update frequency
                            PF.UpdateFrequency(ch);
                        }
                    }
                    //all good, exit
                    break;
                }
                
            }
            catch(InputMismatchException e)
            {
                System.out.println("Error Occured. Please contact your administrator.");
                //Clear invalid input from scanner buffer.
                userInput.nextLine();
            }
        }
        userInput.close();
    }
}//end of user interface class
