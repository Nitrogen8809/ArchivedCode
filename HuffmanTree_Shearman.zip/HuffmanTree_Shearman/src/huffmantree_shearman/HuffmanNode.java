/*
* Name: Walker Shearman
* Class: CSCI 303 - A - Advanced Data Structures and Algorithms 1, Fall 2021
* Date: 11/4/21
*/

package huffmantree_shearman;

import java.util.Comparator;


class HuffmanNode 
{
    int data;
    char c;
 
    HuffmanNode left;
    HuffmanNode right;
}
 

class MyComparator implements Comparator<HuffmanNode> 
{
    public int compare(HuffmanNode x, HuffmanNode y)
    {
 
        return x.data - y.data;
    }
}