/*
* Name: Walker Shearman
* Class: CSCI 303 - A - Advanced Data Structures and Algorithms 1, Fall 2021
* Date: 11/4/21
*/

package huffmantree_shearman;

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class HuffmanTree_Shearman 
{
    //driver method
    public static void main(String[] args) 
    {
        Scanner s = new Scanner(System.in);
        PhraseAndFrequencies PF= new PhraseAndFrequencies();
        
        PF.distinctChars = new ArrayList<>();
        PF.frequencies = new ArrayList<>();
        
        UserInterface.ObtainCharacters(PF);
        PF.printArrays(); //for quality control
        
        PriorityQueue<HuffmanNode> q = new PriorityQueue<>
        (PF.distinctChars.size(), new MyComparator());
        
        AddToQueue(q, PF);
        
        //create a root node
        HuffmanNode root = null;
        
        root = ExtractNodes(q, root);
        
        //print the codes by traversing the tree
        UserInterface.printCode(root, "");
    }
        
    public static void AddToQueue(PriorityQueue<HuffmanNode> q,
            PhraseAndFrequencies PF)
    {
        for (int i = 0; i < PF.distinctChars.size(); i++)
        {
            HuffmanNode hn = new HuffmanNode();

            hn.c = PF.distinctChars.get(i);
            hn.data = PF.frequencies.get(i);

            hn.left = null;
            hn.right = null;

            //add functions adds the huffman nodef to the queue
            q.add(hn);
        }
    }
    
    public static HuffmanNode ExtractNodes(PriorityQueue<HuffmanNode> q,
            HuffmanNode root)
    {
        while (q.size() > 1)
        {
            //first min extract.
            HuffmanNode x = q.peek();
            q.poll();
            
            //second min extract.
            HuffmanNode y = q.peek();
            q.poll();
            
            //new node f which is equal
            HuffmanNode f = new HuffmanNode();
            // to the sun of the frequency of the two nodes
            // assigning values to the f node.
            f.data = x.data + y.data;
            f.c = '-';
            //first extracted node as left child.
            f.left = x;
            //second extrated node as the right child.
            f.right = y;
            // marking the f node as the root node.
            root = f;
            //add this node to the priotity-queue.
            q.add(f);
        }
        return root;
    }
    
}//end Huffmanree_LastName class
