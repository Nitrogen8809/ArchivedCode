/*
* Name: Walker Shearman
* Class: CSCI 303 - A - Advanced Data Structures and Algorithms 1, Fall 2021
* Date: 11/4/21
*/

package huffmantree_shearman;

import java.util.ArrayList;

public class PhraseAndFrequencies 
{
    ArrayList<Character> distinctChars = new ArrayList<>();
    ArrayList<Integer> frequencies = new ArrayList<>();
    
    public void AddCharacter(char ch)
    {
        distinctChars.add(ch);
        frequencies.add(1);
    }
    
    public void UpdateFrequency(char ch)
    {
        int loc = distinctChars.indexOf(ch);
        int freq = frequencies.get(loc);
        frequencies.set(loc, freq +1);
    }
    
    public int checkCharacter(char ch)
    {
        //returns index or -1 if not in list
        return distinctChars.indexOf(ch);
    }
    
    public void printArrays()
    {
        System.out.println(distinctChars);
        System.out.println(frequencies);
    }
}
