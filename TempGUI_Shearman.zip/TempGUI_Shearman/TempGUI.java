/*
 * This is the code for the first Assignment for CSCI 282 A
 * Walker Shearman, Computer Engineering
 * 3/15/21
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class TempGUI extends JFrame
{
    private int win_wid = 500;
    private int win_hei = 200;
    
    private JLabel fahrenLab, celsiusLab;
    private JTextField fahrenField, celsiusField;
    
    private JButton convertBut, clearBut;
    
    public TempGUI()
    {
        this.setTitle("Convert Temperature");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(win_wid, win_hei);
        
        initWin();
        
        this.setVisible(true);        
    }

    public static void main(String[] args)
    {
        new TempGUI();
    }
    
    public void clear()
    {
        fahrenField.setText("");
        celsiusField.setText("");
    }
    
    public void processTemp()
    {
        double fahrenheit = 0 , celsius = 0;
        DecimalFormat twoDigits = new DecimalFormat("0.00");
        if (celsiusField.getText() == null || "".equals(celsiusField.getText().trim())) 
        {
            fahrenheit = Double.parseDouble(fahrenField.getText());
            celsius = (fahrenheit - 32) *   5.0/9.0;
            celsiusField.setText(" " + twoDigits.format(celsius));
        } 
    }
    
    public boolean checkValid()
    {  
        try
        {
            Double.parseDouble(fahrenField.getText());
    
        }
        
        catch(NumberFormatException nfe)
        {
            JOptionPane.showMessageDialog(null,"You have enterted an incorret value!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
      
      return true;  
    }
    
    public void initWin()
    {
        int titleFontSize = 25;
        int labFontSize = 15;
        
        Font titleFont = new Font("Arial", Font.BOLD, titleFontSize);
        Font labFont = new Font("Aria1", Font.BOLD, labFontSize);
        
        JPanel northPan = new JPanel();
        JLabel titleLab = new JLabel("Convert to Celsius");
        titleLab.setFont(titleFont);
        titleLab.setForeground(Color.blue);
        northPan.add(titleLab);
        this.add(northPan, BorderLayout.NORTH);
        
        JPanel centerPan = new JPanel (new GridLayout(2,2));
        fahrenLab = new JLabel("Enter Fahrenheit temp.  ");
        fahrenLab.setFont(labFont);
        fahrenLab.setHorizontalAlignment(JLabel.RIGHT);
        centerPan.add(fahrenLab);
        fahrenField = new JTextField();
        centerPan.add(fahrenField);
        
        celsiusLab = new JLabel("Celsius temp.  ");
        celsiusLab.setFont(labFont);
        celsiusLab.setHorizontalAlignment(JLabel.RIGHT);
        centerPan.add(celsiusLab);
        celsiusField = new JTextField();
        celsiusField.setFont(labFont);
        centerPan.add(celsiusField);
        this.add(centerPan, BorderLayout.CENTER);
        
        JPanel southPan = new JPanel();
        convertBut = new JButton("Convert");
        convertBut.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent me)
            {
                System.err.print("Convert Button clicked");
                processTemp();
            }
        });
        
        convertBut.setFont(labFont);
        
        clearBut = new JButton("Clear");
        clearBut.setFont(labFont);
        
        clearBut.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent me)
            {
                    System.err.print("Clear Button clicked");
                    clear();
            }
        });
        
        southPan.add(convertBut);
        southPan.add(clearBut);
        this.add(southPan, BorderLayout.SOUTH);             
    }
}
