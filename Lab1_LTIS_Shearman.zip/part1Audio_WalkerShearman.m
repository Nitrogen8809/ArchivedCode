[x,fs]= audioread('AudioForLab.wav');
sound(x,fs);

figure;
plot(x);
xlabel('Length (Samples)');
ylabel('Frequency (Samples/sec)');
title('Input Signal');
disp(audioinfo('AudioForLab.wav'));

figure;
n = 0:1000;
h = 0.1*((0.99).^n);
plot(h)
xlabel('Length (Samples)')
ylabel('Impulse Response')
title('LTI System; Impulse Response')


figure;
y = conv(x,h);
plot(y)
xlabel('Length (Samples)')
ylabel('Impulse Response')
title('Output Signal')
disp(audioinfo('AudioForLab.wav'));
sound(y);