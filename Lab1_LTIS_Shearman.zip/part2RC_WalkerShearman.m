t = 0:0.01:10;
Vin = heaviside(t) - heaviside(t-1);
plot (t, Vin);
xlabel('Length (s)');
ylabel('Voltage');
title('Step Function: Input Voltage')
figure;

RC = (500*(10^3))*(1*(10^-6));
h = (1)./(RC)*exp((-t)./(RC));
plot(t,h);
xlabel('Length (s)');
ylabel('Impulse Function')
title('Impulse Response of RC');
figure;

Vout = conv(Vin, h);
Vout_limited = Vout(1:length(t));
plot(t,Vout_limited);
xlabel('Length (s)');
ylabel('Output Voltage');
title('Step Function: Output Voltage')