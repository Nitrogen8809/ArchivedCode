/*
 * This is the code for M3 Lab 1 for CSCI 282 A
 * Christopher Breaux, Computer Science, and Walker Shearman, Computer Engineering
 */

import javax.swing.*;

    public class CruiseShip extends Ship
    {
        private int strooms;
        private int dblrooms;
        private int ecorooms;
       
       
        public CruiseShip(String name, int year, String country, int sr, int dr, int er)
        {
            super(name, year, country);
            strooms = sr;
            dblrooms = dr;
            ecorooms = er; 
        }
     
     
        public int getStateCabins()
        {
            return strooms;
        }
        
        public int getDoubleCabins()
        {
            return dblrooms;
        }
     
        public int getEconomyCabins()
        {
            return ecorooms;
        }
     
        public String toString()
        {
            String string = super.toString()+","+strooms+","+dblrooms+","+ecorooms;
            return string;
        }
    }