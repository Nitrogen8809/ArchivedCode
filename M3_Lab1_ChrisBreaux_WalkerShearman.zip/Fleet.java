/*
 * Code provided for Lab 2 in CSCI282
 * author: C.Anderson
 * modified on 8-31-2016
 */

//package shipping_problem;
import java.util.*;
import javax.swing.*;


public class Fleet {

    private Ship[] shipsOfFleet;

    /**
     * Class constructor
     */
    public Fleet()
    {
        String intro = "This program will initialize a fleet of cargo, cruise\n"+
                       "and battle ships.  It will than print out a fleet Roster\n"+
                       "and a record of resources";
        
        JOptionPane.showMessageDialog(null, intro,"Fleet introduction",1);
        //Create Cargo fleet
        shipsOfFleet = new Ship[12];
        shipsOfFleet[0] = new CargoShip("Balinda", 1998, "USA",  20000,4500 );
        shipsOfFleet[1] = new CargoShip("Sassy Boy", 2008, "UK", 2400, 3300.5);
        shipsOfFleet[2] = new CargoShip("Gut Frau", 1976, "Germany", 3600, 7533);
        shipsOfFleet[3] = new CargoShip("Atlas", 1983, "Porta Rico", 6600, 1000);
        shipsOfFleet[4] = new CargoShip("Big Hauler", 2000, "Russia", 16600, 4536);

        //Create Cruise fleet
        shipsOfFleet[5]= new CruiseShip("Small World", 1998, "USA",100, 250, 500);
        shipsOfFleet[6]= new CruiseShip("Ocean Skipper", 2012, "UK",200, 750, 1500);
        shipsOfFleet[7]= new CruiseShip("Light Sail", 1967, "Brasil", 50, 200, 1200);
        shipsOfFleet[8]= new CruiseShip("Pleasant Berth", 1985, "Germany", 120, 200, 300);
        shipsOfFleet[9]= new CruiseShip("Fast and Loose", 2013, "USA", 45, 51, 129);

        //Create War fleet
        shipsOfFleet[10] = new BattleShip("Tough Guy", 1998, "USA", 100,500);
        shipsOfFleet[11] = new BattleShip("Angry One", 2008, "UK", 300,1500);

        JOptionPane.showMessageDialog(null, "Fleet Roster:\n"+makeFleetRoster()+"\n"+countTheFleet(), "Fleet Roster", 1);
        JOptionPane.showMessageDialog(null, "Program terminating", "Exiting program", 1); 
        
      
        
    }

    
    /**
     * Will return a summery of fleet resources
     * @return 
     */
    private String countTheFleet()
    {
        String fleetCount ="\n\nResources of Fleet:\n";
        int cargoShipCount = 0;
        int totalFreezerSpace = 0;
        int totalCargoCapacity =0;
        int cruiseShipCount = 0;
        int passengerBerthing = 0;  
        int battleShipCount = 0;
        int totalWeaponsCapacity =0;
        int totalFighterCapacity =0;

        for(int dex = 0; dex < shipsOfFleet.length; dex++)
        {
            if(shipsOfFleet[dex] instanceof CargoShip)
            {
                cargoShipCount++;
                totalCargoCapacity += ((CargoShip)shipsOfFleet[dex]).getMaxTonnage();
                totalFreezerSpace += ((CargoShip)shipsOfFleet[dex]).getFreezerSpace();
            }
            else if(shipsOfFleet[dex] instanceof CruiseShip)
            {
                cruiseShipCount++;
                passengerBerthing += ((CruiseShip)shipsOfFleet[dex]).getDoubleCabins()*2 +
                                     ((CruiseShip)shipsOfFleet[dex]).getStateCabins()*2 +
                                     ((CruiseShip)shipsOfFleet[dex]).getEconomyCabins();
            }
            else
            {
                battleShipCount++;
                totalWeaponsCapacity += ((BattleShip)shipsOfFleet[dex]).getWeapons();
                totalFighterCapacity += ((BattleShip)shipsOfFleet[dex]).getFighters();
            }
        }

        fleetCount += "\nCargo Fleet:" +
                      "\nCargo ship count: "+cargoShipCount +
                      "\ntotal cargo capacity: "+totalCargoCapacity +
                      "\ntotal freezer capacity: "+totalFreezerSpace +
                
                      "\n\nCruise Fleet"+
                      "\nCruise ship count: "+cruiseShipCount +
                      "\ntotal passenger berthing: "+passengerBerthing +
                      "\n\nBattle Fleet"+
                      "\nBattle ship count: "+battleShipCount +
                      "\ntotal weapons capacity: "+totalWeaponsCapacity +
                      "\ntotal fighter capacity: "+totalFighterCapacity ;
        return fleetCount;
    }

    /** 
     * Will return a listing of each ship in the fleet along with its capacity 
     * @return 
     */
    private String makeFleetRoster()
    {
        String fleetRoster ="";
        for(int dex = 0; dex < shipsOfFleet.length; dex++)
        {
            
            fleetRoster += "\n"+shipsOfFleet[dex].toString();
        }
        return fleetRoster;
    }


    public static void main(String[] args)
    {
    	Runnable r = new Runnable() 
    	{
			@Override
			public void run() 
			{
    			Fleet myFleet = new Fleet();
    		}
		};
		SwingUtilities.invokeLater(r);
	}
}
