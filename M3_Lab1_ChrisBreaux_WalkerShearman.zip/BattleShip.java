/*
 * This is the code for M3 Lab 1 for CSCI 282 A
 * Christopher Breaux, Computer Science, and Walker Shearman, Computer Engineering
 */


public class BattleShip extends Ship {
   
    private int wepncap;
    private int fightercap;
   
   
    public BattleShip (String name, int year, String country, int wc, int fic)
    {
        super(name, year, country);
        wepncap = wc;
        fightercap = fic;
    }
   
    public int getWeapons()
    {
        return wepncap;
    }
   
    public int getFighters()
    {
        return fightercap;
    }
   
    public String toString()
    {
        String string = super.toString()+","+wepncap+","+fightercap;
        return string;
    }
}
