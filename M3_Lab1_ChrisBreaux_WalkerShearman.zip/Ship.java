/*
 * This is the code for the M2 Lab for CSCI 282 A
 * Christopher Breaux, Computer Science; Walker Shearman, Computer Engineering
 * 3/1/21
 */

import java.io.*;
import java.util.*;
import javax.swing.*;

public class Ship
{
    public String name;
    public String year;
    public String country;

    public Ship(String nm, String yr, String ctry)
    {
        name = nm;
        year = yr;
        country = ctry;
    }

    public String getName()
    {
        return name;
    }
    public String getYear()
    {
        return year;
    }
    public String getCountry()
    {
        return country;
    }
    public String toString()
    {
        return name + ", " + year + ", flag: " + country;
    }

    static void List(ArrayList<Ship> boats, int size)
    {
        String message = "Ships:\n";
        for (int counter = 0; counter < size; counter++)
        {
            message += "    " + (counter + 1) + ": " + boats.get(counter).toString() + "\n";
        }
        JOptionPane.showMessageDialog(null, message, "Ship List", 1);
    }

    public static void main(String[] arg)
    {
        String filename = "justShips.csv";
        File file = new File(filename);
        ArrayList<Ship> ships = new ArrayList<Ship>();

        try
        {
            Scanner inScanner = new Scanner(file).useDelimiter("[,\n]");
            
            while(inScanner.hasNext())
            {
                String name = inScanner.next();
                String year = inScanner.next();
                String country = inScanner.next();
                
                Ship boat = new Ship(name, year, country);
                ships.add(boat);
            }
        }
        
        catch(IOException ioe)
        {
            System.out.print (ioe.toString());
            System.out.print(" Could not find file " + filename);
        }
        int length = ships.size();
        List(ships, length);
    }   
}        