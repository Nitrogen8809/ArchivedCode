/*
 * This is the code for M3 Lab 1 for CSCI 282 A
 * Christopher Breaux, Computer Science, and Walker Shearman, Computer Engineering
 */

public class CargoShip extends Ship {
   
    private int cargocap;
    private double freezercap;
   
   
    public CargoShip (String name, int year, String country, int cc, double frc)
    {
        super(name, year, country);
        cargocap = cc;
        freezercap = frc;
    }
   
    public int getMaxTonnage()
    {
        return cargocap;
    }
   
    public double getFreezerSpace()
    {
        return freezercap;
    }
   
    public String toString()
    {
        String string = super.toString()+","+cargocap+","+freezercap;
        return string;
    }
}
