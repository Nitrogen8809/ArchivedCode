/*
 * Code provided for Lab 3 in CSCI282
 * author: C.Anderson
 * modified on 1-31-2014
 */
//package shipping_problem;
import java.io.*;
import java.util.*;
import javax.swing.*;
/**
 *
 * @author canderson
 */
public class Fleet2 {
    
    private Ship[] shipsOfFleet;
    private int MARK_LIMIT = 32000;
   
    /**
     * Class constructor
     */
    public Fleet2()
    {
        String intro = "This program will initialize a fleet of cargo, cruise\n"+
                       "and battle ships from the data in the file you will be\n"+
                       "asked to select.  It will than print out a fleet Roster\n"+
                       "and a record of resources";
        
        JOptionPane.showMessageDialog(null, intro,"Fleet introduction",1);
        // Create Cargo fleet
        String fileName = enterFileName("Select fleet ship information file");
    
        boolean status = loadShipsFromFile(fileName);
        if(status)
        {
        	// Make display
        	JOptionPane.showMessageDialog(null, "Fleet Roster:\n"+makeFleetRoster()+"\n"+countTheFleet(), "Fleet Roster", 1); 
        	JOptionPane.showMessageDialog(null, "Program terminating", "exiting program", 1);
        }
    }

    /**
     * Will load the ship data from file to shipOfFleet array
     * to the class array shipsOfFleet
     * @param fileName 
     */
    public boolean  loadShipsFromFile(String fileName)
    {
        String line = "";
        int y = 0;
        shipsOfFleet = new Ship[16];
        int x, wc, fic, cc, sr, dr, er;
        double frc;
        
        
        try   
        {  
            BufferedReader br = new BufferedReader(new FileReader(fileName));  
            while ((line = br.readLine()) != null)
            {  
                if(line.contains("CA"))
                {
                    String[] Ships = line.split(",");
                    x = Integer.parseInt(Ships[2]);
                    cc = Integer.parseInt(Ships[4]);
                    frc = Double.parseDouble(Ships[5]);
                    shipsOfFleet[y] = new CargoShip(Ships[1], x, Ships[3], cc, frc);   
                }
                else if(line.contains("CR"))
                {
                    String[] Ships = line.split(",");
                    x = Integer.parseInt(Ships[2]);
                    sr = Integer.parseInt(Ships[4]);
                    dr = Integer.parseInt(Ships[5]);
                    er = Integer.parseInt(Ships[6]);
                    shipsOfFleet[y] = new CruiseShip(Ships[1], y, Ships[3], sr, dr, er);       
                }
                else
                {
                    String[] Ships = line.split(",");
                    x = Integer.parseInt(Ships[2]);
                    wc = Integer.parseInt(Ships[4]);
                    fic = Integer.parseInt(Ships[5]);
                    shipsOfFleet[y] = new BattleShip(Ships[1], x, Ships[3], wc, fic);
                     
                } 
                y++;
            }  
        } 
        
        catch(IOException ioe)
        {
            System.out.print (ioe.toString());
            System.out.print(" Could not find file " +fileName);
        }        
        
        return true;
    }
    
  
    /**
     * Will return a file handle for the file selected for the purpose 
     * stated in the argument string
     * @param purpose
     * @return 
     */
    public static String enterFileName(String purpose)
    {
        String fileName = "";
        //  Creating a new JFilechooser with the argurment that states the directory to start in
        //  This might be a good parameter to pass from the enterFileName method (currently no arguments
        //  instead of hard coding it.
        JFileChooser chooser = new JFileChooser("");
        chooser.setDialogTitle(purpose);
        int returnVal = chooser.showOpenDialog(null);
        if(returnVal == JFileChooser.APPROVE_OPTION) // checking to make sure a non-null value was returned
                                                     //  or that you did not just hit cancel
        {   
            fileName = chooser.getSelectedFile().getAbsolutePath();  // This will return the full 
                                                                     // path to the file
        }
        else
        {
            System.err.print("No file was chosen, program terminating.\nTry again when you are serious about the reports!");
            System.exit(0);
        }
        return fileName;
    }
    
     
    /**
     * Will return a summery of fleet resources
     * @return 
     */
    private String countTheFleet()
    {
        String fleetCount ="";
        int cargoShipCount = 0;
        int totalFreezerSpace = 0;
        int totalCargoCapacity =0;
        int cruiseShipCount = 0;
        int passengerBerthing = 0;  
        int battleShipCount = 0;
        int totalWeaponsCapacity =0;
        int totalFighterCapacity =0;

        for(int dex = 0; dex < shipsOfFleet.length; dex++)
        {
            if(shipsOfFleet[dex] instanceof CargoShip)
            {
                cargoShipCount++;
                totalCargoCapacity += ((CargoShip)shipsOfFleet[dex]).getMaxTonnage();
                totalFreezerSpace += ((CargoShip)shipsOfFleet[dex]).getFreezerSpace();
            }
            else if(shipsOfFleet[dex] instanceof CruiseShip)
            {
                cruiseShipCount++;
                passengerBerthing += ((CruiseShip)shipsOfFleet[dex]).getDoubleCabins()*2 +
                                     ((CruiseShip)shipsOfFleet[dex]).getStateCabins()*2 +
                                     ((CruiseShip)shipsOfFleet[dex]).getEconomyCabins();
            }
            else
            {
                battleShipCount++;
                totalWeaponsCapacity += ((BattleShip)shipsOfFleet[dex]).getWeapons();
                totalFighterCapacity += ((BattleShip)shipsOfFleet[dex]).getFighters();
            }
        }

        fleetCount += "\n Christopher Breaux and Walker Shearman\n" +
                      "\nCargo Fleet:" +
                      "\nCargo ship count: "+cargoShipCount +
                      "\ntotal cargo capacity: "+totalCargoCapacity +
                      "\ntotal freezer capacity: "+totalFreezerSpace +
                
                      "\n\nCruise Fleet:"+
                      "\nCruise ship count: "+cruiseShipCount +
                      "\ntotal passenger berthing: "+passengerBerthing +
                      "\n\nBattle Fleet:"+
                      "\nBattle ship count: "+battleShipCount +
                      "\ntotal weapons capacity: "+totalWeaponsCapacity +
                      "\ntotal fighter capacity: "+totalFighterCapacity ;
        return fleetCount;
    }

    /** 
     * Will return a listing of each ship in the fleet along with its capacity 
     * @return 
     */
    private String makeFleetRoster()
    {
        String fleetRoster ="";
        for(int dex = 0; dex < shipsOfFleet.length; dex++)
        {
            
            fleetRoster += "\n"+shipsOfFleet[dex].toString();
        }
        return fleetRoster;
    }
    

    public static void main(String[] args)
    {
    	//required because of file chooser
    	Runnable r = new Runnable() 
    	{
			@Override
			public void run() 
			{
    			Fleet2 myFleet = new Fleet2();
    		}
		};
		SwingUtilities.invokeLater(r);
	}
}
