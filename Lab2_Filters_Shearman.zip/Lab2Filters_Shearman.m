f = (1:10000);
pi = 3.14;
Q = 1;
f0 = 1000;
w0 = 2*pi*f0;
wz = w0;
w = 2*pi.*f;
s = 1j*w;
fraction = ((s).^(2)+((w0)./Q).*(s)+(w0).^2);

%% Lowpass Filter
LP = ((w0).^(2))./fraction;
semilogx(f,20*log10(abs(LP)));
xlabel ('Frequency (Hz)');
ylabel ('Magnitude (dB)');
title('Lowpass Filter');
figure;

%% Bandpass Filter
BP = (((w0)./(Q)).*s)./fraction;
semilogx(f,20*log10(abs(BP)));
xlabel ('Frequency (Hz)');
ylabel ('Magnitude (dB)');
title('Bandpass Filter');
figure;

%% Notch Filter
Notch = ((s).^2+(wz).^2)./fraction;
semilogx(f,20*log10(abs(Notch)));
xlabel ('Frequency (Hz)');
ylabel ('Magnitude (dB)');
title('Notch (Band Reject) Filter');
figure;

%% Highpass Filter
HP = (s.^2)./fraction;
semilogx(f,20*log10(abs(HP)));
xlabel ('Frequency (Hz)');
ylabel ('Magnitude (dB)');
title('Highpass Filter');